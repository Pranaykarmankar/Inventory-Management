/**
 * @fileoverview Product routes
 * Defines all API endpoints for product operations
 */

const express = require('express');
const router = express.Router();
const {
  createProduct,
  getAllProducts,
  getProductById,
  updateProduct,
  deleteProduct,
} = require('../controllers/productController');
const {
  validateCreateProduct,
  validateUpdateProduct,
  validateProductId,
} = require('../middleware/validation');

/**
 * @route   POST /api/products
 * @desc    Create a new product
 * @access  Public
 */
router.post('/', validateCreateProduct, createProduct);

/**
 * @route   GET /api/products
 * @desc    Get all products
 * @access  Public
 */
router.get('/', getAllProducts);

/**
 * @route   GET /api/products/:id
 * @desc    Get a single product by ID
 * @access  Public
 */
router.get('/:id', validateProductId, getProductById);

/**
 * @route   PUT /api/products/:id
 * @desc    Update a product by ID
 * @access  Public
 */
router.put('/:id', validateUpdateProduct, updateProduct);

/**
 * @route   DELETE /api/products/:id
 * @desc    Delete a product by ID
 * @access  Public
 */
router.delete('/:id', validateProductId, deleteProduct);

module.exports = router;

