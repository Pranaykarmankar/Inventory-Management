# Node.js Product Inventory Manager

A RESTful API for managing product inventory with robust server-side validation. Built with Node.js, Express.js, MongoDB, and express-validator.

## 📋 Table of Contents

- [Project Overview](#project-overview)
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Configuration](#configuration)
- [Running the Application](#running-the-application)
- [API Endpoints](#api-endpoints)
- [Validation Rules](#validation-rules)
- [API Documentation](#api-documentation)
- [Testing the API](#testing-the-api)
- [Project Structure](#project-structure)

## 🎯 Project Overview

This project implements a complete REST API for product inventory management with comprehensive server-side validation. The API ensures data integrity by validating all incoming requests before processing, preventing bad data from entering the database.

## ✨ Features

- **Full CRUD Operations**: Create, Read, Update, and Delete products
- **Server-Side Validation**: Comprehensive validation using express-validator
- **Database Validation**: Checks for SKU uniqueness and supplier existence
- **Error Handling**: Clear, structured error responses
- **MongoDB Integration**: Uses Mongoose for database operations
- **Supplier Support**: Optional supplier association with validation
- **RESTful Design**: Follows REST API best practices

## 🛠 Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: MongoDB with Mongoose
- **Validation**: express-validator
- **Environment**: dotenv
- **CORS**: cors middleware

## 📦 Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** (v14 or higher) - [Download](https://nodejs.org/)
- **MongoDB** (v4.4 or higher) - [Download](https://www.mongodb.com/try/download/community)
- **npm** or **yarn** package manager
- A code editor (VS Code recommended)

## 🚀 Installation

1. **Clone or download this repository**

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   - Copy `env.example` to `.env`
   - Update the MongoDB connection string if needed
   ```bash
   cp env.example .env
   ```

4. **Start MongoDB**
   - Make sure MongoDB is running on your system
   - Default connection: `mongodb://localhost:27017`

## ⚙️ Configuration

Edit the `.env` file with your configuration:

```env
MONGODB_URI=mongodb://localhost:27017/inventory_db
PORT=3000
NODE_ENV=development
```

### MongoDB Connection Options

- **Local MongoDB**: `mongodb://localhost:27017/inventory_db`
- **MongoDB Atlas**: `mongodb+srv://username:password@cluster.mongodb.net/inventory_db`
- **Custom Port**: `mongodb://localhost:27018/inventory_db`

## ▶️ Running the Application

### Development Mode (with auto-reload)

```bash
npm run dev
```

### Production Mode

```bash
npm start
```

The server will start on `http://localhost:3000` (or the port specified in `.env`).

## 📡 API Endpoints

### Base URL
```
http://localhost:3000/api
```

### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/products` | Create a new product |
| GET | `/api/products` | Get all products |
| GET | `/api/products/:id` | Get a single product by ID |
| PUT | `/api/products/:id` | Update a product by ID |
| DELETE | `/api/products/:id` | Delete a product by ID |

## ✅ Validation Rules

### Product Validation

#### `productName`
- **Required**: Yes
- **Type**: String
- **Length**: 3-100 characters

#### `sku` (Stock Keeping Unit)
- **Required**: Yes
- **Format**: Must match `ABC-12345` (3 uppercase letters, hyphen, 5 digits)
- **Uniqueness**: Must be unique across all products (server-side check)

#### `quantity`
- **Required**: Yes
- **Type**: Integer (whole number)
- **Range**: ≥ 0

#### `unitPrice`
- **Required**: Yes
- **Type**: Number (decimal allowed)
- **Range**: > 0.00

#### `supplierId` (Optional)
- **Type**: MongoDB ObjectId
- **Existence**: Must reference an existing supplier (server-side check)

## 📚 API Documentation

See [API-DOCS.md](./API-DOCS.md) for detailed API documentation including:
- Request/response examples
- Error response formats
- Validation error examples
- Sample curl commands

## 🧪 Testing the API

### Using cURL

#### Create a Product
```bash
curl -X POST http://localhost:3000/api/products \
  -H "Content-Type: application/json" \
  -d '{
    "productName": "Laptop Computer",
    "sku": "LAP-12345",
    "quantity": 50,
    "unitPrice": 999.99,
    "supplierId": null
  }'
```

#### Get All Products
```bash
curl http://localhost:3000/api/products
```

#### Get Product by ID
```bash
curl http://localhost:3000/api/products/PRODUCT_ID_HERE
```

#### Update a Product
```bash
curl -X PUT http://localhost:3000/api/products/PRODUCT_ID_HERE \
  -H "Content-Type: application/json" \
  -d '{
    "quantity": 75,
    "unitPrice": 899.99
  }'
```

#### Delete a Product
```bash
curl -X DELETE http://localhost:3000/api/products/PRODUCT_ID_HERE
```

### Using Postman

1. Import the API collection (see API-DOCS.md)
2. Set the base URL variable
3. Test each endpoint

### Using Thunder Client (VS Code Extension)

1. Install Thunder Client extension
2. Import the API collection
3. Test endpoints directly in VS Code

## 📁 Project Structure

```
nodejs-inventory-manager/
├── config/
│   └── database.js          # Database connection configuration
├── controllers/
│   └── productController.js # Business logic for products
├── middleware/
│   └── validation.js        # Validation middleware
├── models/
│   ├── Product.js            # Product schema/model
│   └── Supplier.js           # Supplier schema/model
├── routes/
│   └── productRoutes.js      # Product route definitions
├── .gitignore               # Git ignore file
├── env.example              # Environment variables template
├── package.json             # Project dependencies
├── README.md                # This file
├── API-DOCS.md              # Detailed API documentation
└── server.js                # Main server file
```

## 🔍 Key Implementation Details

### Validation Flow

1. **Request arrives** → Express middleware
2. **Validation middleware** → Checks all rules using express-validator
3. **Database checks** → Verifies SKU uniqueness and supplier existence
4. **If valid** → Proceeds to controller
5. **If invalid** → Returns 400 with detailed error messages

### Error Response Format

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "sku",
      "message": "SKU must match format: ABC-12345",
      "value": "invalid-sku"
    }
  ]
}
```

### Success Response Format

```json
{
  "success": true,
  "message": "Product created successfully",
  "data": {
    "_id": "...",
    "productName": "...",
    "sku": "...",
    ...
  }
}
```

## 🐛 Troubleshooting

### MongoDB Connection Issues

- Ensure MongoDB is running: `mongod` or check service status
- Verify connection string in `.env`
- Check firewall settings if using remote MongoDB

### Port Already in Use

- Change `PORT` in `.env` file
- Or kill the process using the port

### Validation Errors

- Check the error response for specific field issues
- Ensure all required fields are provided
- Verify data types match requirements

## 📝 License

This project is created for educational purposes.

## 👨‍💻 Author

Created as part of a university course or portfolio assignment.

---

**Note**: Make sure MongoDB is running before starting the server!

