const API_BASE = 'http://localhost:3000/api/products';

let editingProductId = null;

// Load products on page load
document.addEventListener('DOMContentLoaded', () => {
    loadProducts();
    setupForm();
});

function setupForm() {
    const form = document.getElementById('productForm');
    form.addEventListener('submit', handleSubmit);
}

async function handleSubmit(e) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData(form);
    
    const productData = {
        productName: formData.get('productName'),
        sku: formData.get('sku').toUpperCase(),
        quantity: parseInt(formData.get('quantity')),
        unitPrice: parseFloat(formData.get('unitPrice')),
    };
    
    const supplierId = formData.get('supplierId')?.trim();
    if (supplierId) {
        productData.supplierId = supplierId;
    }
    
    try {
        let response;
        if (editingProductId) {
            // Update existing product
            response = await fetch(`${API_BASE}/${editingProductId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(productData),
            });
        } else {
            // Create new product
            response = await fetch(API_BASE, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(productData),
            });
        }
        
        const data = await response.json();
        
        if (response.ok) {
            showMessage('success', editingProductId 
                ? 'Product updated successfully!' 
                : 'Product created successfully!');
            form.reset();
            editingProductId = null;
            document.getElementById('form-title').textContent = 'Create New Product';
            document.getElementById('submitBtn').textContent = 'Create Product';
            document.getElementById('updateBtn').style.display = 'none';
            loadProducts();
        } else {
            // Show validation errors
            if (data.errors && data.errors.length > 0) {
                const errorMessages = data.errors.map(err => err.message).join('<br>');
                showMessage('error', `Validation failed:<ul>${data.errors.map(e => `<li>${e.message}</li>`).join('')}</ul>`);
            } else {
                showMessage('error', data.message || 'An error occurred');
            }
        }
    } catch (error) {
        showMessage('error', 'Network error: ' + error.message);
    }
}

async function loadProducts() {
    const productsList = document.getElementById('productsList');
    productsList.innerHTML = '<p class="loading">Loading products...</p>';
    
    try {
        const response = await fetch(API_BASE);
        const data = await response.json();
        
        if (data.success) {
            if (data.data.length === 0) {
                productsList.innerHTML = '<div class="empty-state">No products found. Create your first product!</div>';
            } else {
                productsList.innerHTML = data.data.map(product => createProductCard(product)).join('');
            }
        } else {
            productsList.innerHTML = '<div class="empty-state">Error loading products</div>';
        }
    } catch (error) {
        productsList.innerHTML = '<div class="empty-state">Error: ' + error.message + '</div>';
    }
}

function createProductCard(product) {
    const supplierInfo = product.supplierId 
        ? `<div class="supplier-info"><strong>Supplier:</strong> ${product.supplierId.supplierName || product.supplierId}</div>`
        : '';
    
    return `
        <div class="product-card">
            <div class="product-header">
                <div class="product-name">${product.productName}</div>
                <div class="product-sku">${product.sku}</div>
            </div>
            <div class="product-details">
                <div class="detail-item">
                    <span class="detail-label">Quantity</span>
                    <span class="detail-value">${product.quantity}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Unit Price</span>
                    <span class="detail-value">$${product.unitPrice.toFixed(2)}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Total Value</span>
                    <span class="detail-value">$${(product.quantity * product.unitPrice).toFixed(2)}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Created</span>
                    <span class="detail-value">${new Date(product.createdAt).toLocaleDateString()}</span>
                </div>
            </div>
            ${supplierInfo}
            <div class="product-actions">
                <button class="btn-edit" onclick="editProduct('${product._id}')">✏️ Edit</button>
                <button class="btn-delete" onclick="deleteProduct('${product._id}')">🗑️ Delete</button>
            </div>
        </div>
    `;
}

async function editProduct(id) {
    try {
        const response = await fetch(`${API_BASE}/${id}`);
        const data = await response.json();
        
        if (data.success) {
            const product = data.data;
            document.getElementById('productName').value = product.productName;
            document.getElementById('sku').value = product.sku;
            document.getElementById('quantity').value = product.quantity;
            document.getElementById('unitPrice').value = product.unitPrice;
            document.getElementById('supplierId').value = product.supplierId?._id || '';
            
            editingProductId = id;
            document.getElementById('form-title').textContent = 'Edit Product';
            document.getElementById('submitBtn').textContent = 'Update Product';
            document.getElementById('updateBtn').style.display = 'inline-block';
            
            // Scroll to form
            document.querySelector('.form-section').scrollIntoView({ behavior: 'smooth' });
        }
    } catch (error) {
        showMessage('error', 'Error loading product: ' + error.message);
    }
}

function cancelUpdate() {
    editingProductId = null;
    document.getElementById('productForm').reset();
    document.getElementById('form-title').textContent = 'Create New Product';
    document.getElementById('submitBtn').textContent = 'Create Product';
    document.getElementById('updateBtn').style.display = 'none';
}

async function deleteProduct(id) {
    if (!confirm('Are you sure you want to delete this product?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/${id}`, {
            method: 'DELETE',
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showMessage('success', 'Product deleted successfully!');
            loadProducts();
        } else {
            showMessage('error', data.message || 'Error deleting product');
        }
    } catch (error) {
        showMessage('error', 'Error: ' + error.message);
    }
}

function showMessage(type, message) {
    const messageEl = document.getElementById('message');
    messageEl.className = `message ${type}`;
    messageEl.innerHTML = message;
    
    setTimeout(() => {
        messageEl.className = 'message';
        messageEl.innerHTML = '';
    }, 5000);
}

