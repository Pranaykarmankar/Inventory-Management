/**
 * @fileoverview Database seed script
 * Creates sample suppliers and products for testing
 */

require('dotenv').config();
const mongoose = require('mongoose');
const Product = require('../models/Product');
const Supplier = require('../models/Supplier');

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('MongoDB Connected for seeding...');
  } catch (error) {
    console.error('Database connection error:', error.message);
    process.exit(1);
  }
};

const seedData = async () => {
  try {
    // Clear existing data
    await Product.deleteMany({});
    await Supplier.deleteMany({});
    console.log('Cleared existing data...');

    // Create suppliers
    const suppliers = await Supplier.insertMany([
      {
        supplierName: 'Tech Supplies Inc',
        contactEmail: 'contact@techsupplies.com',
        phone: '+1-555-0101',
      },
      {
        supplierName: 'Global Electronics',
        contactEmail: 'sales@globalelectronics.com',
        phone: '+1-555-0202',
      },
      {
        supplierName: 'Office Depot Pro',
        contactEmail: 'orders@officedepot.com',
        phone: '+1-555-0303',
      },
    ]);
    console.log(`Created ${suppliers.length} suppliers...`);

    // Create products
    const products = await Product.insertMany([
      {
        productName: 'Laptop Computer',
        sku: 'LAP-12345',
        quantity: 50,
        unitPrice: 999.99,
        supplierId: suppliers[0]._id,
      },
      {
        productName: 'Wireless Mouse',
        sku: 'MOU-67890',
        quantity: 100,
        unitPrice: 29.99,
        supplierId: suppliers[0]._id,
      },
      {
        productName: 'Mechanical Keyboard',
        sku: 'KEY-11111',
        quantity: 75,
        unitPrice: 79.99,
        supplierId: suppliers[1]._id,
      },
      {
        productName: 'USB-C Cable',
        sku: 'CAB-22222',
        quantity: 200,
        unitPrice: 12.99,
        supplierId: null, // No supplier
      },
      {
        productName: 'Monitor Stand',
        sku: 'STA-33333',
        quantity: 30,
        unitPrice: 49.99,
        supplierId: suppliers[2]._id,
      },
    ]);
    console.log(`Created ${products.length} products...`);

    console.log('\n✅ Seed data created successfully!');
    console.log('\nSample Supplier IDs:');
    suppliers.forEach((supplier) => {
      console.log(`  - ${supplier.supplierName}: ${supplier._id}`);
    });
    console.log('\nSample Product SKUs:');
    products.forEach((product) => {
      console.log(`  - ${product.productName}: ${product.sku}`);
    });
    console.log('\nYou can now test the API endpoints!');

    process.exit(0);
  } catch (error) {
    console.error('Error seeding data:', error);
    process.exit(1);
  }
};

// Run seed
connectDB().then(() => {
  seedData().then(() => {
    mongoose.connection.close();
  });
});

