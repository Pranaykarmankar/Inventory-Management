# API Documentation

Complete API documentation for the Product Inventory Manager.

## Base URL

```
http://localhost:3000/api
```

## Response Format

All responses are in JSON format. Success responses include a `success: true` field, while error responses include `success: false` with an `errors` array.

---

## Endpoints

### 1. Create a Product

**POST** `/api/products`

Creates a new product with server-side validation.

#### Request Body

```json
{
  "productName": "Laptop Computer",
  "sku": "LAP-12345",
  "quantity": 50,
  "unitPrice": 999.99,
  "supplierId": null
}
```

#### Required Fields

- `productName` (string, 3-100 characters)
- `sku` (string, format: ABC-12345)
- `quantity` (integer, ≥ 0)
- `unitPrice` (number, > 0)

#### Optional Fields

- `supplierId` (MongoDB ObjectId, must exist in database)

#### Success Response (201 Created)

```json
{
  "success": true,
  "message": "Product created successfully",
  "data": {
    "_id": "64f1a2b3c4d5e6f7g8h9i0j1",
    "productName": "Laptop Computer",
    "sku": "LAP-12345",
    "quantity": 50,
    "unitPrice": 999.99,
    "supplierId": null,
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  }
}
```

#### Error Response (400 Bad Request)

**Example 1: Missing required field**

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "productName",
      "message": "Product name is required",
      "value": ""
    }
  ]
}
```

**Example 2: Invalid SKU format**

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "sku",
      "message": "SKU must match format: ABC-12345 (3 uppercase letters, hyphen, 5 digits)",
      "value": "lap12345"
    }
  ]
}
```

**Example 3: Duplicate SKU**

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "sku",
      "message": "SKU already exists. Each product must have a unique SKU",
      "value": "LAP-12345"
    }
  ]
}
```

**Example 4: Invalid quantity**

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "quantity",
      "message": "Quantity must be a non-negative integer",
      "value": -5
    }
  ]
}
```

**Example 5: Invalid supplier ID**

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "supplierId",
      "message": "Supplier with the provided ID does not exist",
      "value": "64f1a2b3c4d5e6f7g8h9i0j1"
    }
  ]
}
```

#### cURL Example

```bash
curl -X POST http://localhost:3000/api/products \
  -H "Content-Type: application/json" \
  -d '{
    "productName": "Laptop Computer",
    "sku": "LAP-12345",
    "quantity": 50,
    "unitPrice": 999.99
  }'
```

---

### 2. Get All Products

**GET** `/api/products`

Retrieves all products from the database.

#### Success Response (200 OK)

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "_id": "64f1a2b3c4d5e6f7g8h9i0j1",
      "productName": "Laptop Computer",
      "sku": "LAP-12345",
      "quantity": 50,
      "unitPrice": 999.99,
      "supplierId": null,
      "createdAt": "2024-01-15T10:30:00.000Z",
      "updatedAt": "2024-01-15T10:30:00.000Z"
    },
    {
      "_id": "64f1a2b3c4d5e6f7g8h9i0j2",
      "productName": "Wireless Mouse",
      "sku": "MOU-67890",
      "quantity": 100,
      "unitPrice": 29.99,
      "supplierId": {
        "_id": "64f1a2b3c4d5e6f7g8h9i0j3",
        "supplierName": "Tech Supplies Inc",
        "contactEmail": "contact@techsupplies.com"
      },
      "createdAt": "2024-01-15T11:00:00.000Z",
      "updatedAt": "2024-01-15T11:00:00.000Z"
    }
  ]
}
```

#### cURL Example

```bash
curl http://localhost:3000/api/products
```

---

### 3. Get Product by ID

**GET** `/api/products/:id`

Retrieves a single product by its MongoDB ObjectId.

#### URL Parameters

- `id` (required): MongoDB ObjectId of the product

#### Success Response (200 OK)

```json
{
  "success": true,
  "data": {
    "_id": "64f1a2b3c4d5e6f7g8h9i0j1",
    "productName": "Laptop Computer",
    "sku": "LAP-12345",
    "quantity": 50,
    "unitPrice": 999.99,
    "supplierId": null,
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  }
}
```

#### Error Response (400 Bad Request - Invalid ID)

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "id",
      "message": "Invalid product ID format",
      "value": "invalid-id"
    }
  ]
}
```

#### Error Response (404 Not Found)

```json
{
  "success": false,
  "message": "Product not found"
}
```

#### cURL Example

```bash
curl http://localhost:3000/api/products/64f1a2b3c4d5e6f7g8h9i0j1
```

---

### 4. Update a Product

**PUT** `/api/products/:id`

Updates an existing product. All fields are optional, but provided fields must pass validation.

#### URL Parameters

- `id` (required): MongoDB ObjectId of the product

#### Request Body (all fields optional)

```json
{
  "productName": "Updated Laptop Computer",
  "sku": "LAP-99999",
  "quantity": 75,
  "unitPrice": 899.99,
  "supplierId": "64f1a2b3c4d5e6f7g8h9i0j3"
}
```

#### Success Response (200 OK)

```json
{
  "success": true,
  "message": "Product updated successfully",
  "data": {
    "_id": "64f1a2b3c4d5e6f7g8h9i0j1",
    "productName": "Updated Laptop Computer",
    "sku": "LAP-99999",
    "quantity": 75,
    "unitPrice": 899.99,
    "supplierId": {
      "_id": "64f1a2b3c4d5e6f7g8h9i0j3",
      "supplierName": "Tech Supplies Inc",
      "contactEmail": "contact@techsupplies.com"
    },
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T12:00:00.000Z"
  }
}
```

#### Error Response (400 Bad Request)

Same validation errors as POST endpoint.

#### Error Response (404 Not Found)

```json
{
  "success": false,
  "message": "Product not found"
}
```

#### cURL Example

```bash
curl -X PUT http://localhost:3000/api/products/64f1a2b3c4d5e6f7g8h9i0j1 \
  -H "Content-Type: application/json" \
  -d '{
    "quantity": 75,
    "unitPrice": 899.99
  }'
```

---

### 5. Delete a Product

**DELETE** `/api/products/:id`

Deletes a product by its MongoDB ObjectId.

#### URL Parameters

- `id` (required): MongoDB ObjectId of the product

#### Success Response (200 OK)

```json
{
  "success": true,
  "message": "Product deleted successfully",
  "data": {
    "_id": "64f1a2b3c4d5e6f7g8h9i0j1",
    "productName": "Laptop Computer",
    "sku": "LAP-12345",
    "quantity": 50,
    "unitPrice": 999.99,
    "supplierId": null,
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  }
}
```

#### Error Response (400 Bad Request - Invalid ID)

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "id",
      "message": "Invalid product ID format",
      "value": "invalid-id"
    }
  ]
}
```

#### Error Response (404 Not Found)

```json
{
  "success": false,
  "message": "Product not found"
}
```

#### cURL Example

```bash
curl -X DELETE http://localhost:3000/api/products/64f1a2b3c4d5e6f7g8h9i0j1
```

---

## Validation Rules Summary

| Field | Required | Type | Constraints |
|-------|----------|------|-------------|
| `productName` | Yes | String | 3-100 characters |
| `sku` | Yes | String | Format: `ABC-12345`, must be unique |
| `quantity` | Yes | Integer | ≥ 0 |
| `unitPrice` | Yes | Number | > 0.00 |
| `supplierId` | No | ObjectId | Must exist in database if provided |

---

## Error Codes

| Status Code | Description |
|-------------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request (Validation Error) |
| 404 | Not Found |
| 500 | Internal Server Error |

---

## Testing Examples

### Create a Valid Product

```bash
curl -X POST http://localhost:3000/api/products \
  -H "Content-Type: application/json" \
  -d '{
    "productName": "Gaming Keyboard",
    "sku": "KEY-11111",
    "quantity": 25,
    "unitPrice": 79.99
  }'
```

### Create Product with Invalid Data

```bash
curl -X POST http://localhost:3000/api/products \
  -H "Content-Type: application/json" \
  -d '{
    "productName": "AB",
    "sku": "invalid",
    "quantity": -5,
    "unitPrice": 0
  }'
```

### Update Product (Partial Update)

```bash
curl -X PUT http://localhost:3000/api/products/PRODUCT_ID \
  -H "Content-Type: application/json" \
  -d '{
    "quantity": 100
  }'
```

---

## Postman Collection

You can import these endpoints into Postman:

1. Create a new collection: "Product Inventory API"
2. Set base URL variable: `{{baseUrl}}` = `http://localhost:3000/api`
3. Add each endpoint with the examples above

---

## Notes

- All timestamps are in ISO 8601 format (UTC)
- SKU values are automatically converted to uppercase
- Supplier information is populated when `supplierId` is provided
- All validation happens server-side before database operations

