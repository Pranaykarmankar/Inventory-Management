/**
 * @fileoverview Validation middleware using express-validator
 * Contains validation rules and error handling for product endpoints
 */

const { body, param, validationResult } = require('express-validator');
const Product = require('../models/Product');
const Supplier = require('../models/Supplier');

/**
 * Middleware to handle validation errors
 * Returns formatted error response if validation fails
 */
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array().map((error) => ({
        field: error.path || error.param,
        message: error.msg,
        value: error.value,
      })),
    });
  }
  next();
};

/**
 * Validation rules for creating a new product (POST)
 */
const validateCreateProduct = [
  // productName validation
  body('productName')
    .trim()
    .notEmpty()
    .withMessage('Product name is required')
    .isString()
    .withMessage('Product name must be a string')
    .isLength({ min: 3, max: 100 })
    .withMessage('Product name must be between 3 and 100 characters'),

  // sku validation
  body('sku')
    .trim()
    .notEmpty()
    .withMessage('SKU is required')
    .isString()
    .withMessage('SKU must be a string')
    .matches(/^[A-Z]{3}-[0-9]{5}$/)
    .withMessage('SKU must match format: ABC-12345 (3 uppercase letters, hyphen, 5 digits)')
    .custom(async (value) => {
      const existingProduct = await Product.findOne({ sku: value.toUpperCase() });
      if (existingProduct) {
        throw new Error('SKU already exists. Each product must have a unique SKU');
      }
      return true;
    }),

  // quantity validation
  body('quantity')
    .notEmpty()
    .withMessage('Quantity is required')
    .isInt({ min: 0 })
    .withMessage('Quantity must be a non-negative integer')
    .toInt(),

  // unitPrice validation
  body('unitPrice')
    .notEmpty()
    .withMessage('Unit price is required')
    .isFloat({ min: 0.01 })
    .withMessage('Unit price must be a number greater than 0')
    .toFloat(),

  // supplierId validation (optional)
  body('supplierId')
    .optional()
    .isMongoId()
    .withMessage('Supplier ID must be a valid MongoDB ObjectId')
    .custom(async (value) => {
      if (value) {
        const supplier = await Supplier.findById(value);
        if (!supplier) {
          throw new Error('Supplier with the provided ID does not exist');
        }
      }
      return true;
    }),

  handleValidationErrors,
];

/**
 * Validation rules for updating a product (PUT)
 */
const validateUpdateProduct = [
  // ID validation
  param('id')
    .isMongoId()
    .withMessage('Invalid product ID format'),

  // productName validation (optional for updates)
  body('productName')
    .optional()
    .trim()
    .notEmpty()
    .withMessage('Product name cannot be empty')
    .isString()
    .withMessage('Product name must be a string')
    .isLength({ min: 3, max: 100 })
    .withMessage('Product name must be between 3 and 100 characters'),

  // sku validation (optional for updates, but must check uniqueness if provided)
  body('sku')
    .optional()
    .trim()
    .notEmpty()
    .withMessage('SKU cannot be empty')
    .isString()
    .withMessage('SKU must be a string')
    .matches(/^[A-Z]{3}-[0-9]{5}$/)
    .withMessage('SKU must match format: ABC-12345 (3 uppercase letters, hyphen, 5 digits)')
    .custom(async (value, { req }) => {
      const existingProduct = await Product.findOne({
        sku: value.toUpperCase(),
        _id: { $ne: req.params.id }, // Exclude current product
      });
      if (existingProduct) {
        throw new Error('SKU already exists. Each product must have a unique SKU');
      }
      return true;
    }),

  // quantity validation (optional for updates)
  body('quantity')
    .optional()
    .isInt({ min: 0 })
    .withMessage('Quantity must be a non-negative integer')
    .toInt(),

  // unitPrice validation (optional for updates)
  body('unitPrice')
    .optional()
    .isFloat({ min: 0.01 })
    .withMessage('Unit price must be a number greater than 0')
    .toFloat(),

  // supplierId validation (optional)
  body('supplierId')
    .optional()
    .isMongoId()
    .withMessage('Supplier ID must be a valid MongoDB ObjectId')
    .custom(async (value) => {
      if (value) {
        const supplier = await Supplier.findById(value);
        if (!supplier) {
          throw new Error('Supplier with the provided ID does not exist');
        }
      }
      return true;
    }),

  handleValidationErrors,
];

/**
 * Validation rules for product ID parameter
 */
const validateProductId = [
  param('id')
    .isMongoId()
    .withMessage('Invalid product ID format'),
  handleValidationErrors,
];

module.exports = {
  validateCreateProduct,
  validateUpdateProduct,
  validateProductId,
  handleValidationErrors,
};

